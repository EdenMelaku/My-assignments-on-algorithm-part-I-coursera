
import java.util.Iterator;
public class Deque<Item> implements Iterable<Item> {

    private Node first;
    private Node last;
    private int numberOfItems;
    private class Node{
        Item item;
        Node next;
    }

    public Deque(){
     first = null;
     last = first;
     numberOfItems = 0;
    }
    // construct an empty deque

    public boolean isEmpty(){

        return first == null;


    }                 // is the deque empty?

    public int size(){

       return numberOfItems;
    }                      // return the number of items on the deque
    public void addFirst(Item item){

        if (item == null){

            throw new java.lang.IllegalArgumentException();

        }

        if(isEmpty()){

            first.item=item;
            first.next=null;
            last=first;
            return;
        }

        Node oldFirst=first;
        first.item=item;
        first.next=oldFirst;

    }          // add the item to the front
    public void addLast(Item item){

        if (item == null){

            throw new java.lang.IllegalArgumentException();
        }

        if(isEmpty()){
            first.item=item;
            first.next=null;
            last=first;
            return;
        }

        Node oldLast=last;
        last.item=item;
        last.next=oldLast;
    }         // add the item to the end
    public Item removeFirst(){

        if(isEmpty()){

            throw new java.util.NoSuchElementException();

        }

        Item i=first.item;

        first.next=null;
        return i;
    }                // remove and return the item from the front
    public Item removeLast(){
        if(isEmpty()){

           throw new java.util.NoSuchElementException();
        }

        Item i=last.item;
        Node x=first;
        Iterator iter=iterator();
        int j=0;
        while (iter.hasNext() && j < numberOfItems){
           x=x.next;
           j++;
        }
        x.next=null;
        last=x;
        return i;

    }                // remove and return the item from the end



    public Iterator<Item> iterator(){
    return new ListIterator();

    }         // return an iterator over items in order from front to end
    private class ListIterator implements Iterator<Item>
    {
        private Node current = first;
        public boolean hasNext()
        {
            return current != null;

        }

        public void remove()

        { /* not supported */
            throw new java.lang.UnsupportedOperationException();
        }

        public Item next()
        {

            Item item = current.item;
            if (item == null){
               throw new java.util.NoSuchElementException();
            }
            current = current.next;
            return item;
        }
    }


    public static void main(String[] args){




    }  // unit testing (optional)
}

