import java.util.Iterator;
import edu.princeton.cs.algs4.StdRandom;
public class RandomizedQueue<Item> implements Iterable<Item> {


    Node n;
    Node first;
    Node last;
    private int numberOfItems;
    private class Node{
        Item item;
        Node next;
    }


    public RandomizedQueue(){

    n=new Node();
    first=null;
    last=first;

    }                 // construct an empty randomized queue
    public boolean isEmpty(){
        return numberOfItems==0;


    }                 // is the randomized queue empty?
    public int size(){
      return numberOfItems;

    }                        // return the number of items on the randomized queue
    public void enqueue(Item item){
      Node oldFirst=first;
      first.item=item;
      first.next=oldFirst;


    }           // add the item
    public Item dequeue(){

        if(isEmpty()){

            throw new java.util.NoSuchElementException();
        }
        int randnum=StdRandom.uniform(1,numberOfItems);

        Item i=null;
        Node x=first;
        Iterator iter=iterator();
        int j=1;
        while (iter.hasNext()){
            if(j==randnum-1){
               i=x.next.item;
               x.next=x.next.next;
            }
            x=x.next;
            j++;
        }



       return i;

    }                    // remove and return a random item
    public Item sample(){

        if(isEmpty()){

            throw new java.util.NoSuchElementException();
        }
        int randnum=StdRandom.uniform(1,numberOfItems);

        Item i=null;
        Node x=first;
        Iterator iter=iterator();
        int j=1;
        while (iter.hasNext()){
            if(j==randnum-1){
                i=x.next.item;

            }
            x=x.next;
            j++;
        }



        return i;


    }                     // return a random item (but do not remove it)

    public Iterator<Item> iterator(){
        return new ListIterator();

    }         // return an iterator over items in random order
    private class ListIterator implements Iterator<Item>
    {
        private Node current = first;
        public boolean hasNext()
        {
            return current != null;

        }

        public void remove()

        { /* not supported */
            throw new java.lang.UnsupportedOperationException();
        }

        public Item next()
        {

            Item item = current.item;
            if (item == null){
                throw new java.util.NoSuchElementException();
            }
            current = current.next;
            return item;
        }
    }







    public static void main(String[] args){




    }   // unit testing (optional)
}
