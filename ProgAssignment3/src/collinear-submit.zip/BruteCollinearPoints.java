

public class BruteCollinearPoints {
    public BruteCollinearPoints(Point[] points)  {




    }  // finds all line segments containing 4 points
    public int numberOfSegments(){

return 0;

    }        // the number of line segments
    public LineSegment[] segments()    {

    return null;

    }            // the line segments
}

